jQuery(document).ready(function($) {
  console.log('0202902');
});
