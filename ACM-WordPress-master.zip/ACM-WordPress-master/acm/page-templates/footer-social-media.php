<?php
/**
 * Template Name: Footer Social Media Template
 *
 * @package WordPress
 * @subpackage Baseline
 * @since Baseline 0.1
 */ 
?>
